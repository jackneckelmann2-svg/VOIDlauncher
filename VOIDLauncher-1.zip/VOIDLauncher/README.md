# VOID Launcher — V0.1 (Home Screen only)

Un launcher Android reale, completamente personalizzato, pensato per Google Pixel 9a.

**Stack**
- Kotlin
- Jetpack Compose + Material 3
- Min SDK 26 / Target SDK 35
- Nessuna dipendenza a pagamento
- Nessun backend

## Struttura del progetto

```
VOIDLauncher/
├── app/
│   ├── build.gradle.kts
│   ├── proguard-rules.pro
│   └── src/main/
│       ├── AndroidManifest.xml          ← HOME intent-filter corretto
│       ├── java/com/voidlauncher/
│       │   ├── MainActivity.kt
│       │   ├── data/
│       │   │   └── AppRepository.kt     ← legge le app reali installate
│       │   ├── model/
│       │   │   └── AppInfo.kt
│       │   └── ui/
│       │       ├── theme/               ← colori, tipografia, tema dark
│       │       ├── components/          ← Glass, Clock, Weather, Search, Dock, Icon
│       │       └── home/
│       │           └── HomeScreen.kt    ← unica schermata V0.1
│       └── res/
│           ├── values/
│           ├── drawable/
│           ├── mipmap-anydpi-v26/
│           └── xml/
├── build.gradle.kts
├── settings.gradle.kts
├── gradle.properties
└── gradle/wrapper/gradle-wrapper.properties
```

## Cosa fa V0.1

- Wallpaper dark/futuristico (gradient + supporto system wallpaper)
- Grande orologio + data in alto
- Widget meteo glass (placeholder statico)
- Search bar stile Pixel, trasparente, apre la ricerca di sistema
- Griglia di **tutte le app realmente installate** con le loro icone
- Contenitori glass attorno alle icone
- Dock inferiore con effetto glass
- Haptic feedback leggero al tap
- Intent filter HOME + DEFAULT → può essere impostato come launcher predefinito
- Architettura modulare pronta per App Library, Control Center, Music, ecc.

## Come aprire il progetto in Android Studio

1. Apri **Android Studio** (versione Hedgehog / Iguana / Ladybug o più recente consigliata).
2. **File → Open** e seleziona la cartella `VOIDLauncher`.
3. Aspetta che Gradle sincronizzi (Android Studio scaricherà le dipendenze automaticamente).
4. Se ti chiede di aggiornare il Gradle Plugin o l’AGP, accetta le versioni proposte (il progetto usa AGP 8.7.3 + Kotlin 2.0.21 + Compose BOM 2024.12.01).

Se la sincronizzazione fallisce per mancanza di SDK:
- **Tools → SDK Manager** → installa **Android 15 (API 35)** e **Android SDK Build-Tools**.

## Come compilare l’APK

### Da Android Studio
1. Seleziona il build variant **debug** (o **release**).
2. **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
3. Al termine clicca **locate** per trovare il file:
   - Debug: `app/build/outputs/apk/debug/app-debug.apk`
   - Release: `app/build/outputs/apk/release/app-release-unsigned.apk`

### Da terminale
```bash
cd VOIDLauncher
./gradlew assembleDebug
# oppure
./gradlew assembleRelease
```

L’APK debug si trova in:
`app/build/outputs/apk/debug/app-debug.apk`

> Nota: su Windows usa `gradlew.bat`.

## Come installarlo sul Pixel 9a

### Metodo 1 – USB + ADB (consigliato)
1. Sul Pixel: **Impostazioni → Informazioni sul telefono → Tocca 7 volte “Numero build”** per attivare le opzioni sviluppatore.
2. **Opzioni sviluppatore → Debug USB** → attiva.
3. Collega il telefono al PC e autorizza il debug.
4. Dal terminale:
```bash
adb devices          # verifica che il device sia connesso
adb install -r app/build/outputs/apk/debug/app-debug.apk
```

### Metodo 2 – Trasferimento file
1. Copia l’APK sul telefono (Drive, cavo, Nearby Share…).
2. Apri il file con **File** o **Files by Google**.
3. Consenti l’installazione da fonti sconosciute se richiesto.
4. Installa.

## Come impostarlo come launcher predefinito

1. Dopo l’installazione apri **VOID Launcher** almeno una volta.
2. Premi il pulsante **Home**.
3. Apparirà il selettore “Quale app Home vuoi usare?”.
4. Scegli **VOID Launcher** e tocca **Sempre** (o “Always”).

In alternativa:
**Impostazioni → App → App predefinite → App Home** → seleziona **VOID Launcher**.

## Note importanti

- Su Android 11+ è obbligatorio il blocco `<queries>` nel Manifest (già presente). Senza di esso `queryIntentActivities` restituisce una lista quasi vuota.
- Il meteo è un placeholder statico. Nella prossima versione si potrà collegare un provider gratuito (Open-Meteo, ecc.).
- Il blur glass reale (RenderEffect) è disponibile solo da API 31+. Su versioni inferiori viene usato un fallback elegante con trasparenza + bordo.
- `onBackPressed` è volontariamente vuoto: un launcher non deve chiudersi con il tasto Indietro.

## Prossimi passi (non ancora implementati)

- App Library con swipe-up
- Control Center
- Music Player
- Widget lockscreen-style
- Personalizzazione (icone, colori, layout)
- Caching icone + receiver PACKAGE_ADDED/REMOVED

---

**VOID Launcher V0.1** — stabile, compilabile e installabile.
Testa pure la Home prima di aggiungere qualsiasi altra funzione.

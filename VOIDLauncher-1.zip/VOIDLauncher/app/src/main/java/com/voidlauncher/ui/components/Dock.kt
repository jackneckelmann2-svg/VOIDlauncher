package com.voidlauncher.ui.components

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.voidlauncher.model.AppInfo

/**
 * Bottom dock with glass effect.
 * Shows up to 5 apps (typically the first few or pinned later).
 */
@Composable
fun Dock(
    apps: List<AppInfo>,
    onAppClick: (AppInfo) -> Unit,
    modifier: Modifier = Modifier
) {
    val dockApps = apps.take(5)

    Row(
        modifier = modifier
            .fillMaxWidth()
            .glassSurface(cornerRadius = 28.dp, strong = true)
            .padding(horizontal = 12.dp, vertical = 12.dp),
        horizontalArrangement = Arrangement.SpaceEvenly,
        verticalAlignment = Alignment.CenterVertically
    ) {
        dockApps.forEach { app ->
            AppIconItem(
                app = app,
                onClick = { onAppClick(app) },
                showLabel = false
            )
        }
    }
}

package com.voidlauncher.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.voidlauncher.ui.theme.VoidGlass
import com.voidlauncher.ui.theme.VoidGlassBorder
import com.voidlauncher.ui.theme.VoidGlassStrong

/**
 * Soft glassmorphism surface.
 * Uses translucent gradient + subtle border for a premium look.
 * Blur is intentionally omitted on the surface itself to keep icons and text sharp;
 * the overall dark theme + transparency already conveys the glass effect natively.
 */
fun Modifier.glassSurface(
    cornerRadius: Dp = 20.dp,
    borderWidth: Dp = 0.8.dp,
    strong: Boolean = false
): Modifier {
    val shape = RoundedCornerShape(cornerRadius)
    return this
        .clip(shape)
        .background(
            brush = Brush.verticalGradient(
                colors = listOf(
                    if (strong) VoidGlassStrong else VoidGlass,
                    Color.Transparent
                )
            ),
            shape = shape
        )
        .border(
            width = borderWidth,
            brush = Brush.verticalGradient(
                colors = listOf(
                    VoidGlassBorder.copy(alpha = 0.45f),
                    VoidGlassBorder.copy(alpha = 0.12f)
                )
            ),
            shape = shape
        )
}

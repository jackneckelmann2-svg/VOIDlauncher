package com.voidlauncher.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val VoidColorScheme = darkColorScheme(
    primary = VoidAccent,
    onPrimary = Color.White,
    primaryContainer = VoidBlue,
    onPrimaryContainer = VoidTextPrimary,
    secondary = VoidAccentSoft,
    onSecondary = Color.White,
    background = VoidBlack,
    onBackground = VoidTextPrimary,
    surface = VoidDeepBlue,
    onSurface = VoidTextPrimary,
    surfaceVariant = VoidBlue,
    onSurfaceVariant = VoidTextSecondary,
    outline = VoidGlassBorder
)

@Composable
fun VOIDLauncherTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = VoidColorScheme,
        typography = VoidTypography,
        content = content
    )
}

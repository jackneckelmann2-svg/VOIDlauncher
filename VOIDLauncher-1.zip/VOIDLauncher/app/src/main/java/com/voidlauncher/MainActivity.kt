package com.voidlauncher

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.core.view.WindowCompat
import com.voidlauncher.ui.home.HomeScreen
import com.voidlauncher.ui.theme.VOIDLauncherTheme

/**
 * Main entry point of VOID Launcher.
 *
 * Declared as HOME + DEFAULT + LAUNCHER in the manifest so the system
 * offers it as a default home app.
 *
 * launchMode = singleTask + stateNotNeeded keep a single instance
 * and allow the system to bring it to front cleanly on Home press.
 */
class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Edge-to-edge + transparent system bars
        enableEdgeToEdge()
        WindowCompat.setDecorFitsSystemWindows(window, false)

        setContent {
            VOIDLauncherTheme {
                HomeScreen(
                    modifier = Modifier.fillMaxSize()
                )
            }
        }
    }

    /**
     * Launchers should not finish on back press.
     * We simply stay on the home screen (or later open the App Library).
     */
    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        // Intentionally empty – stay on home
        // Future: if App Library is open, close it instead
    }
}

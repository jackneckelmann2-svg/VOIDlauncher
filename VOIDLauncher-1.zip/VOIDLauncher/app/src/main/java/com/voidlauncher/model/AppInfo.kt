package com.voidlauncher.model

import android.graphics.drawable.Drawable

/**
 * Represents a launchable application installed on the device.
 * Used by the home grid and dock.
 */
data class AppInfo(
    val label: String,
    val packageName: String,
    val activityName: String,
    val icon: Drawable
)

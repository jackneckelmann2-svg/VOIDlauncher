package com.voidlauncher.ui.components

import android.content.Intent
import android.provider.Settings
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.voidlauncher.ui.theme.VoidTextSecondary
import com.voidlauncher.ui.theme.VoidTextTertiary

/**
 * Elegant transparent search bar inspired by Pixel,
 * but with glass treatment. Opens system / Google search.
 */
@Composable
fun SearchBar(
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current

    Row(
        modifier = modifier
            .fillMaxWidth()
            .glassSurface(cornerRadius = 28.dp, strong = true)
            .clickable {
                // Prefer Google / web search, fallback to Settings search
                val searchIntent = Intent(Intent.ACTION_WEB_SEARCH).apply {
                    putExtra("query", "")
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                try {
                    context.startActivity(searchIntent)
                } catch (e: Exception) {
                    // Fallback: open system search or settings
                    val fallback = Intent(Settings.ACTION_SEARCH_SETTINGS).apply {
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    }
                    runCatching { context.startActivity(fallback) }
                }
            }
            .padding(horizontal = 18.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            imageVector = Icons.Rounded.Search,
            contentDescription = "Search",
            tint = VoidTextTertiary,
            modifier = Modifier.size(22.dp)
        )
        Text(
            text = "Search",
            color = VoidTextSecondary,
            fontSize = 16.sp,
            modifier = Modifier.padding(start = 12.dp)
        )
    }
}

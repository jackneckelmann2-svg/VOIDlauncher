package com.voidlauncher.ui.components

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.WbSunny
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.voidlauncher.ui.theme.VoidAccentSoft
import com.voidlauncher.ui.theme.VoidTextPrimary
import com.voidlauncher.ui.theme.VoidTextSecondary

/**
 * Minimal glass weather widget.
 * V0.1 uses static placeholder data (no network / backend).
 * Ready to be replaced by a real provider later.
 */
@Composable
fun WeatherWidget(
    temperature: String = "22°",
    condition: String = "Clear",
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .glassSurface(cornerRadius = 16.dp, strong = false)
            .padding(horizontal = 14.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Icon(
            imageVector = Icons.Rounded.WbSunny,
            contentDescription = null,
            tint = VoidAccentSoft,
            modifier = Modifier.size(18.dp)
        )
        Text(
            text = temperature,
            color = VoidTextPrimary,
            fontSize = 15.sp
        )
        Text(
            text = condition,
            color = VoidTextSecondary,
            fontSize = 13.sp
        )
    }
}

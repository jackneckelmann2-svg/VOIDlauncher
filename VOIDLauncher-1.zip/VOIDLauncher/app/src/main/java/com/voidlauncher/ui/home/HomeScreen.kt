package com.voidlauncher.ui.home

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.voidlauncher.data.AppRepository
import com.voidlauncher.model.AppInfo
import com.voidlauncher.ui.components.ClockWidget
import com.voidlauncher.ui.components.Dock
import com.voidlauncher.ui.components.SearchBar
import com.voidlauncher.ui.components.WeatherWidget
import com.voidlauncher.ui.theme.VoidBlack
import com.voidlauncher.ui.theme.VoidDeepBlue

/**
 * V0.1 Home Screen of VOID Launcher.
 *
 * Layout (top → bottom):
 * 1. Status bar padding
 * 2. Large clock + date
 * 3. Weather glass widget
 * 4. Search bar
 * 5. Scrollable app grid (real installed apps)
 * 6. Glass dock at the bottom
 *
 * Architecture is modular so App Library, Control Center,
 * Music Player, etc. can be added later without rewriting the core.
 */
@Composable
fun HomeScreen(
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val repository = remember { AppRepository(context) }
    val apps = remember { repository.getLaunchableApps() }

    // Soft dark futuristic gradient as wallpaper fallback.
    // When windowShowWallpaper is true the system wallpaper shows behind;
    // this gradient provides a premium look when no wallpaper is set.
    val backgroundBrush = Brush.verticalGradient(
        colors = listOf(
            VoidDeepBlue.copy(alpha = 0.85f),
            VoidBlack.copy(alpha = 0.92f),
            VoidBlack
        )
    )

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(backgroundBrush)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
        ) {
            // ── Top section ──────────────────────────────────────────────
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 24.dp, start = 20.dp, end = 20.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                ClockWidget()

                Spacer(modifier = Modifier.height(12.dp))

                WeatherWidget()

                Spacer(modifier = Modifier.height(20.dp))

                SearchBar()
            }

            Spacer(modifier = Modifier.height(16.dp))

            // ── App grid ─────────────────────────────────────────────────
            LazyVerticalGrid(
                columns = GridCells.Fixed(4),
                contentPadding = PaddingValues(
                    start = 16.dp,
                    end = 16.dp,
                    top = 8.dp,
                    bottom = 120.dp // space for dock
                ),
                verticalArrangement = Arrangement.spacedBy(18.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
            ) {
                items(
                    items = apps,
                    key = { it.packageName }
                ) { app ->
                    AppGridItem(
                        app = app,
                        onClick = { repository.launchApp(app) }
                    )
                }
            }
        }

        // ── Dock (pinned above navigation bar) ───────────────────────────
        Dock(
            apps = apps,
            onAppClick = { repository.launchApp(it) },
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(horizontal = 20.dp, vertical = 16.dp)
                .navigationBarsPadding()
        )
    }
}

@Composable
private fun AppGridItem(
    app: AppInfo,
    onClick: () -> Unit
) {
    com.voidlauncher.ui.components.AppIconItem(
        app = app,
        onClick = onClick,
        showLabel = true
    )
}

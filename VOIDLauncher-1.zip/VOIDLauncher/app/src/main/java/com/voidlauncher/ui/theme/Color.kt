package com.voidlauncher.ui.theme

import androidx.compose.ui.graphics.Color

// VOID palette – premium dark futuristic
val VoidBlack = Color(0xFF050508)
val VoidDeepBlue = Color(0xFF0A0F1E)
val VoidBlue = Color(0xFF1A2744)
val VoidAccent = Color(0xFF3B82F6)
val VoidAccentSoft = Color(0xFF60A5FA)
val VoidGlass = Color(0x1AFFFFFF)
val VoidGlassStrong = Color(0x26FFFFFF)
val VoidGlassBorder = Color(0x33FFFFFF)
val VoidTextPrimary = Color(0xFFF1F5F9)
val VoidTextSecondary = Color(0xFF94A3B8)
val VoidTextTertiary = Color(0xFF64748B)
